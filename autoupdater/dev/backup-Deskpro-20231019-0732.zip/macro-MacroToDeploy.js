import xapi from 'xapi';

var text = "This is the macro to deploy. Version 1";
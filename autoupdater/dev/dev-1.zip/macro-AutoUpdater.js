import xapi from 'xapi';

const manifestVersion = 1;
const myversion = 1;
const branch = 'https://raw.githubusercontent.com/ZacharieGignac/MCS/main/autoupdater/dev';
var devicebranch = 'https://raw.githubusercontent.com/ZacharieGignac/MCS/main/autoupdater/devices'

async function init() {
  devicebranch = devicebranch + '/' + await xapi.Config.SystemUnit.Name.get();
}

function update(manual = false) {
  console.log(`Fetching update manifest...`);
  xapi.Command.HttpClient.Get({
    AllowInsecureHTTPS: 'True',
    ResultBody: 'PlainText',
    Timeout: 10,
    Url: branch + '/manifest.json?raw=true'
  }).then(response => {
    var updateFound = false;
    console.log(`Got manifest. Reading...`);
    try {
      var manifest = JSON.parse(response.Body);
      if (manifest.version == manifestVersion) {
        console.log(`Manifest version ${manifest.version}, channel "${manifest.channel}", ${manifest.updates.length} total updates available.`);
        console.log(`Looking for next update...`);
        var updates = manifest.updates.sort((a, b) => a.version - b.version);
        for (let update of updates) {
          if (update.version > myversion) {
            console.log(`Found update!`);
            updateFound = true;
            if (update.type == 'auto') {
              console.log(`Update is flagged as "auto". Applying update ${update.version} (${update.file}) in 1 minute.`);
              setTimeout(() => {
                xapi.Command.Provisioning.Service.Fetch({ Mode: update.mode, URL: branch + '/' + update.file + '?raw=true' });
              }, 60000);
              break;
            }
            else if (update.type == 'manual' && !manual) {
              console.log(`Update is flagged as "manual" update. This update will not be installed.`);
            }
            else if (update.type == 'manual' && manual) {
              console.log(`Update is flagged as "auto". Applying update ${update.version} (${update.file})`);
              xapi.Command.Provisioning.Service.Fetch({ Mode: update.mode, URL: branch + '/' + update.file + '?raw=true' });
            }
          }
        }
        if (!updateFound) {
          console.log(`System is up to date.`);
          updateDeviceSpecific();
        }
      }
      else {
        console.error(`Manifest version not compatible. Version ${manifest.version}, expected ${manifestVersion}`);
      }
    }
    catch (err) {
      console.error(`Error reading manifest: ${err}`);
    }
  });
}

function updateDeviceSpecific() {
  console.log(`Fetching update manifest...`);
  xapi.Command.HttpClient.Get({
    AllowInsecureHTTPS: 'True',
    ResultBody: 'PlainText',
    Timeout: 10,
    Url: devicebranch + '/manifest.json?raw=true'
  }).then(response => {
    var updateFound = false;
    console.log(`Got manifest. Reading...`);
    try {
      var manifest = JSON.parse(response.Body);
      if (manifest.version == manifestVersion) {
        console.log(`Manifest version ${manifest.version}, channel "${manifest.channel}", ${manifest.updates.length} total updates available.`);
        console.log(`Looking for next update...`);
        var updates = manifest.updates.sort((a, b) => a.version - b.version);
        for (let update of updates) {
          if (update.version > myversion - 1) {
            console.log(`Found update!`);
            updateFound = true;
            if (update.type == 'auto') {
              console.log(`Update is flagged as "auto". Applying update ${update.version} (${update.file}) in 1 minute.`);
              setTimeout(() => {
                xapi.Command.Provisioning.Service.Fetch({ Mode: update.mode, URL: devicebranch + '/' + update.file + '?raw=true' });
              }, 60000);
              break;
            }
            else if (update.type == 'manual' && !manual) {
              console.log(`Update is flagged as "manual" update. This update will not be installed.`);
            }
            else if (update.type == 'manual' && manual) {
              console.log(`Update is flagged as "auto". Applying update ${update.version} (${update.file})`);
              xapi.Command.Provisioning.Service.Fetch({ Mode: update.mode, URL: devicebranch + '/' + update.file + '?raw=true' });
            }
          }
        }
        if (!updateFound) {
          console.log(`System is up to date.`);
        }
      }
      else {
        console.error(`Manifest version not compatible. Version ${manifest.version}, expected ${manifestVersion}`);
      }
    }
    catch (err) {
      console.error(`Error reading manifest: ${err}`);
    }
  });
}



xapi.Event.UserInterface.Extensions.Widget.Action.on(action => {
  if (action.WidgetId == 'au_getmanifest' && action.Type == 'pressed') {
    update(branch, true);
  }
});

init();
update(branch);


console.log(`Checking for updates in 1 minute...`);
setTimeout(() => {
  //update();
}, 60000);
/*
const manifest = {
  version: 1,
  channel: 'dev',
  updates: [
    {
      version: 1,
      type: 'auto',
      file: 'https://github.com/ZacharieGignac/MCS/blob/main/autoupdater/dev/backup-Deskpro-20231019-0732.zip?raw=true'
    }
  ]
};

console.log(JSON.stringify(manifest));



xapi.Command.Provisioning.Service.Fetch({ Mode: 'Add', URL: 'https://github.com/ZacharieGignac/MCS/blob/main/autoupdater/dev/backup-Deskpro-20231019-0732.zip?raw=true' });
*/
import xapi from 'xapi';

var value = "test 1";
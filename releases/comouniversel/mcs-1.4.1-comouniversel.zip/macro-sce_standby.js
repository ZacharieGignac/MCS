  /* jshint esversion:8 */
  import xapi from 'xapi';
  import { zapiv1 as zapi } from './zapi';
  import { config as systemconfig } from './config';

  function safeStringify(obj, cache = new Set()) {
    return JSON.stringify(obj, (key, value) => {
      if (typeof value === 'object' && value !== null) {
        if (cache.has(value)) {
          // Remove cyclic reference
          return;
        }
        cache.add(value);
      }
      return value;
    });
  }



  export var Manifest = {
    fileName: 'sce_standby',
    id: 'standby',
    friendlyName: 'En veille',
    version: '1.4.1',
    description: 'Comportement standby',
    panels: {
      hide: [],
      show: []
    },
    features: {

    }
  };


  export class Scenario {
    constructor(api) {
      this.standbyTimeout;
    }

    enable() {
      return new Promise(success => {
        success(true);
      });
    }

    disable() {
      return new Promise(success => {
        success(true);
      });
    }

    start() {
      xapi.Command.Audio.Microphones.Unmute().catch(() => {});

      //Clear prompts and alerts
      xapi.Command.UserInterface.Message.Prompt.Clear().catch(() => {});
      xapi.Command.UserInterface.Message.Alert.Clear().catch(() => {});

      //Stop presentation
      xapi.Command.Presentation.Stop().catch(() => {});

      //Stop Selfview
      xapi.Command.Video.Selfview.Set({ Mode:'Off' });

      //Stop HdmiPassthrough (only if active)
      try {
        if (zapi.system && typeof zapi.system.getStatus === 'function' && zapi.system.getStatus('hdmiPassthrough') === 'Active') {
          xapi.Command.Video.Output.HDMI.Passthrough.Stop().catch(() => {});
        }
      } catch (_) {}

      //Set default volume
      xapi.Command.Audio.Volume.SetToDefault().catch(() => {});

      //Disable HDMIPassthrough

      const autoLights = zapi.system.getStatus('AutoLights');
      const lightscenes = zapi.devices.getDevicesByTypeInGroup(zapi.devices.DEVICETYPE.LIGHTSCENE, 'system.lightscene.standby');
      const skipLightReset = (autoLights === 'off') && (lightscenes.length === 0);

      let devices = zapi.devices.getAllDevices();

      for (let d of devices) {
        try {
          if (skipLightReset && (d.config.type === zapi.devices.DEVICETYPE.LIGHT || d.config.type === zapi.devices.DEVICETYPE.LIGHTSCENE)) {
            continue;
          }
          d.reset();
        }
        catch (e) { }
      }

      if (lightscenes.length > 0) {
        for (let lightscene of lightscenes) {
          lightscene.activate();
        }
      }

      zapi.system.resetSystemStatus();
      clearTimeout(this.standbyTimeout);
    }

    test() {

    }
  }